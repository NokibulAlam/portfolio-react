import React from 'react'

const Hero = () => {
  return (
    <div>
      <div className='h-screen bg-theme'>
        <div className='grid lg:grid-cols-2 h-screen items-center'>
          <div className='h-1/2'>
            <lottie-player src="https://assets9.lottiefiles.com/private_files/lf30_WdTEui.json" background="transparent" speed="1" loop autoplay></lottie-player>
          </div>

          <div>
            <h1 className='text-7xl text-txtT font-mont'>Hii, I am Nokibul Alam</h1>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Hero;